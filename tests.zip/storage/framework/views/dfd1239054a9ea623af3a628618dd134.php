<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>User Login</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Login Form Template" name="keywords">
        <meta content="Login Form Template" name="description">

        <!-- Favicon -->
        <link href="<?php echo e(url('img/favicon.ico')); ?>" rel="icon">

        <!-- Stylesheet -->
        <link href="<?php echo e(url('css/style5.css')); ?>" rel="stylesheet">
    </head>
    <body>
        <div class="wrapper login-1">
            <div class="container">
                <div class="col-left">
                
                </div>
                <div class="col-right">
                    <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul>
                        <li><?php echo e($errors); ?></li>
                    
                    </ul>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                        <?php if(session()-> has("message")): ?>
                        <h3><?php echo e(session()->get("message")); ?></h3>
                    
                    <?php endif; ?>
        
                    <div class="login-form">
                        <h2>Login</h2>
                        <form method="POST" action="/send_user_login">
                            <?php echo csrf_field(); ?>
                            <p>
                                <label>Username<span>*</span></label>
                                <input type="text" placeholder="Username" name="username" required>
                            </p>
                            <p>
                                <label>Password<span>*</span></label>
                                <input type="password" placeholder="Password" name="password" required>
                            </p>
                            <p>
                                <input type="submit" value="Log In" />
                            </p>
                            
                        </form>
                    </div>
                </div>
            </div>
        
        </div>
    </body>
</html>
<?php /**PATH C:\Users\user\Desktop\news_blog\resources\views/user_login.blade.php ENDPATH**/ ?>